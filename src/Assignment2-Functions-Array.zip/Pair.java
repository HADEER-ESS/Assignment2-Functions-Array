public class Pair<T1>{

    T1 first;
    T1 second;


    Pair(T1 x, T1 y){
        this.first = x;
        this.second = y;
    }
}
